﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.GestureDetection
{
    public class StubGesture : Gesture
    {
        public StubGesture() : base(0, 100, Constants.NOM_STUB_GESTURE)
        { }

        public override bool TestFinaliseCondition(IReadOnlyDictionary<JointType, Joint> joints)
        {
            return true;
        }

        public override bool TestInitiliseCondition(IReadOnlyDictionary<JointType, Joint> joints)
        {
            return true;
        }

        public override bool TestPosture(IReadOnlyDictionary<JointType, Joint> joints)
        {
            return true;
        }

        public override bool TestRunningGesture(IReadOnlyDictionary<JointType, Joint> joints)
        {
            return true;
        }

        public override void DonwloadPositions(IReadOnlyDictionary<JointType, Joint> joints) { }
    }
}
