﻿using Microsoft.Kinect;
using projet_kinect.Modèle.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.GestureDetection
{
    public abstract class Gesture : BaseGesture
    {
        private bool isRunning=false;

        private int nbFrame;

        private readonly int minFrame;

        private readonly int maxFrame;

        public Gesture(int minFrame, int maxFrame, string nameGesture) : base(nameGesture)
        {
            this.minFrame = minFrame;
            this.maxFrame = maxFrame;
        }

        public abstract bool TestInitiliseCondition(IReadOnlyDictionary<JointType, Joint> joints);

        public abstract bool TestPosture(IReadOnlyDictionary<JointType, Joint> joints);

        public abstract bool TestRunningGesture(IReadOnlyDictionary<JointType, Joint> joints);

        public abstract bool TestFinaliseCondition(IReadOnlyDictionary<JointType, Joint> joints);

        public abstract void DonwloadPositions(IReadOnlyDictionary<JointType, Joint> joints);

        public override bool TestGesture(IReadOnlyDictionary<JointType, Joint> joints)
        {
            if (!isRunning)
            {
                if (TestInitiliseCondition(joints))
                {
                    isRunning = true;
                    nbFrame = 0;
                    DonwloadPositions(joints);
                    return false;
                }
            }
            else
            {
                if (nbFrame>maxFrame || !TestPosture(joints) || !TestRunningGesture(joints))
                {
                    isRunning = false;
                    return false;
                }
                DonwloadPositions(joints);
                nbFrame++;
                if (nbFrame < minFrame)
                    return false;
                if (TestFinaliseCondition(joints))
                {
                    isRunning = false;
                    return true;
                }
            }
            return false;
        }
    }
}
