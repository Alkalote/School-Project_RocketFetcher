﻿using Microsoft.Kinect;
using projet_kinect.Modèle.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.GestureDetection
{
    public abstract class BaseGesture
    {
        public event EventHandler<EventGesture> GestureRecognised;

        private readonly string gesture;

        public BaseGesture(string nameGesture)
        {
            gesture = nameGesture;
        }

        public abstract bool TestGesture(IReadOnlyDictionary<JointType, Joint> joints);

        public void OnGestureRecognised()
        {
            GestureRecognised?.Invoke(this, new EventGesture(gesture));
        }
    }
}
