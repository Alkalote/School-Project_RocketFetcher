﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.GestureDetection
{
    class ThrowGesture : Gesture
    {
        private CameraSpacePoint previousPosition;
        public ThrowGesture() : base(0, 40, Constants.NOM_THROW_GESTURE)
        {

        }

        public override bool TestFinaliseCondition(IReadOnlyDictionary<JointType, Joint> joints)
        {
            if (joints[JointType.HandRight].Position.X > joints[JointType.ShoulderRight].Position.X-0.2
                && joints[JointType.HandRight].Position.Y > joints[JointType.ShoulderRight].Position.Y-0.5
                && joints[JointType.HandRight].Position.Z <= joints[JointType.ShoulderRight].Position.Z-0.5)
                return true;
            return false;
        }

        public override bool TestInitiliseCondition(IReadOnlyDictionary<JointType, Joint> joints)
        {
            if (joints[JointType.HandRight].Position.X > joints[JointType.ShoulderRight].Position.X
                && joints[JointType.HandRight].Position.Y > joints[JointType.ShoulderRight].Position.Y
                && joints[JointType.HandRight].Position.Z <= joints[JointType.ShoulderRight].Position.Z
                && joints[JointType.HandRight].Position.Z >= joints[JointType.ShoulderRight].Position.Z - 0.1)
                return true;
            return false;
        }

        public override bool TestPosture(IReadOnlyDictionary<JointType, Joint> joints)
        {
            if (joints[JointType.HandRight].Position.X > joints[JointType.ShoulderRight].Position.X-0.4
                   && joints[JointType.HandRight].Position.Y > joints[JointType.ShoulderRight].Position.Y-0.6
                   && joints[JointType.HandRight].Position.Z <= joints[JointType.ShoulderRight].Position.Z)
                return true;
            return false;
        }

        public override bool TestRunningGesture(IReadOnlyDictionary<JointType, Joint> joints)
        {
            if (joints[JointType.HandRight].Position.Z<=previousPosition.Z)
                return true;
            return false;
        }

        public override void DonwloadPositions(IReadOnlyDictionary<JointType, Joint> joints)
        {
            previousPosition = joints[JointType.HandRight].Position;
        }
    }
}
