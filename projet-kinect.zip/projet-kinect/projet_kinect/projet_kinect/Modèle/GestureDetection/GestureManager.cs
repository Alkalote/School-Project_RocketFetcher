﻿using Microsoft.Kinect;
using projet_kinect.Modèle.Controllers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.GestureDetection
{
    public static class GestureManager
    {
        private static List<BaseGesture> knowGesture = new List<BaseGesture>();

        public static event EventHandler<EventGesture> GestureRecognised
        {
            add
            {
                foreach (var gesture in knowGesture)
                {
                    gesture.GestureRecognised+=value;
                }
            }
            remove
            {
                foreach (var gesture in knowGesture)
                {
                    gesture.GestureRecognised -= value;
                }
            }
        }

        public static void AddGestureRecognised(BaseGesture gesture)
        {
            knowGesture.Add(gesture);
        }

        public static void OnFrameReceived(IReadOnlyDictionary<JointType, Joint> joints)
        {
            foreach (var gesture in knowGesture)
            {
                if (gesture.TestGesture(joints))
                    gesture.OnGestureRecognised();
            }
        }
    }
}
