﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace projet_kinect.Modèle
{
    public class Constants
    {
        public static readonly string KINECT_BRANCHEE = "Kinected";

        public static readonly string KINECT_NON_BRANCHEE = "Pas de kinect";

        public static readonly string START = "Commencer";

        public static readonly string END_BUTTON = "   Retour\nécran titre";

        public static readonly string END = "GAME OVER";

        public static readonly string IMAGE_FOND_JEU = "Images/testImage.png";

        public static readonly string IMAGE_MONSTRE = "Images/zomb.png";

        public static readonly string NOM_STUB_GESTURE = "stubGesture";

        public static readonly string NOM_THROW_GESTURE = "throwGesture";

        public static readonly string NOM_RIGHT_GESTURE = "rigthGesture";

        public static readonly string NOM_LEFT_GESTURE = "leftGesture";

        public static readonly string NOM_REINITIALIZE_GESTURE = "reinitializeGesture";

        public static readonly int TAILLE_MAIN = 25;

        public static readonly int COEF_TAILLE = 1;

        public static Rect AIR_DE_JEU(int largeur, int hauteur) => new Rect(0.0, 0.0, largeur, hauteur);

        public static readonly Rect BOUTON_START = new Rect(210*COEF_TAILLE, 125*COEF_TAILLE, 100*COEF_TAILLE, 50*COEF_TAILLE);

        public static readonly Rect BOUTON_STOP = new Rect(210 * COEF_TAILLE, 325 * COEF_TAILLE, 95 * COEF_TAILLE, 50 * COEF_TAILLE);

        public static readonly Rect SPELL_USED = new Rect(0, 200 * COEF_TAILLE, 50 * COEF_TAILLE, 50 * COEF_TAILLE);

        public static Point ORIGINE_START_TEXT(Rect r) => new Point(r.Left + 14*COEF_TAILLE, r.Top + 17*COEF_TAILLE);

        public static Point ORIGINE_END_TEXT_BUTTON(Rect r) => new Point(r.Left + 15*COEF_TAILLE, r.Top + 12*COEF_TAILLE);

        public static Point ORIGINE_SPELL_TEXT(Rect r) => new Point(r.Left + 4 * COEF_TAILLE, r.Top + 4 * COEF_TAILLE);

        public static Point ORIGINE_END_TEXT = new Point(150*COEF_TAILLE, 150*COEF_TAILLE);

        public static readonly FormattedText START_TEXT = new FormattedText(START, CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 12*COEF_TAILLE, Brushes.White);

        public static readonly FormattedText END_TEXT_BUTTON = new FormattedText(END_BUTTON, CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 12*COEF_TAILLE, Brushes.White);

        public static readonly FormattedText END_TEXT = new FormattedText(END, CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 36*COEF_TAILLE, Brushes.Red);

        public static readonly SolidColorBrush COULEUR_MAIN = new SolidColorBrush(Color.FromArgb(128, 255, 255, 255));
    }
}
