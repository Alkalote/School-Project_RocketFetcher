﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace projet_kinect.Modèle.Controllers
{
    public class TimerW : INotifyPropertyChanged
    {

        private DispatcherTimer timer;
        private int TimeWaited;

        

        public TimerW()
        {

            timer = new DispatcherTimer();
            timer.Tick += new EventHandler(Tick_Handler);
            timer.Interval = new TimeSpan(0, 0, 1);
            TimeWaited = 0;
            timer.Start();

        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void Tick_Handler(object sender, EventArgs e)
        {
            TimeWaited++;
            OnPropertyChanged();
        }

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public int GetTimeWaited()
        {
            return TimeWaited;
        }

    }
}
