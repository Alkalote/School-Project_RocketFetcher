﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle.Controllers
{
    public class EventGesture : EventArgs
    {
        public readonly string gesture;

        public EventGesture(string nameGesture)
        {
            gesture=nameGesture;
        }
    }
}
