﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace projet_kinect.Modèle.Controllers
{
    public class MoveController
    {
        private Player currPlayer;
        private List<Monster> monsterList;
        private double maxHauteur;
        

        public List<Monster> MonsterList { get => monsterList; set => monsterList = value; }
        public Player CurrPlayer { get => currPlayer; set => currPlayer = value; }

        public TimerW Timer { get=> timer; }
        private TimerW timer;

        public MoveController(Player p,List<Monster> lmons,double maxHauteurDep)
        {
            CurrPlayer = p;
            MonsterList = lmons;
            maxHauteur = maxHauteurDep;
            timer = new TimerW();
            timer.PropertyChanged += HandleCustomEvent;
        }



        public void MovePlayer()
        {
            if (CurrPlayer.IsDead)
            {
                return;
            }

            //Move camera
      


        }

        void HandleCustomEvent(object sender, PropertyChangedEventArgs a)
        {
            MovePlayer();
            MoveMobs();
        }

        public void MoveMobs()
        {
            if (!CurrPlayer.IsDead   )
            {
                foreach (Monster m in MonsterList)
                {
                    if(m.Ypos < maxHauteur)
                    {
                        m.Ypos += m.MoveSpeed;
                    }
                    
                }
            }

        }

        

    }

}