﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace projet_kinect.Modèle
{
    public class Collisions
    {
        public static bool ClickButton(Point mainDroite, Point mainGauche, Rect button)
        {
            if ((mainDroite.X >= button.Left && mainDroite.X <= button.Right
                && mainDroite.Y >= button.Top && mainDroite.Y <= button.Bottom)
                || (mainGauche.X >= button.Left && mainGauche.X <= button.Right
                && mainGauche.Y >= button.Top && mainGauche.Y <= button.Bottom))
                return true;
            return false;
        }
    }
}
