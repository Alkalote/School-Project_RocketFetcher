﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle
{
    class SpawnArea
    {
        private Coordinates posLeftTop = new Coordinates() ;
        private Coordinates posRightTop = new Coordinates();
        private Coordinates posLeftBottom = new Coordinates();
        private Coordinates posRightBottom = new Coordinates();
        private double percentageWindow;

        public SpawnArea(int percentH, double largeur, double hauteur)
        {
            percentageWindow = percentH / 100.0;
            hauteur = percentageWindow*hauteur ;

            posLeftBottom.Y = hauteur;
            posLeftBottom.X = 80;

            posRightBottom.Y = hauteur;
            posRightBottom.X = largeur -60;

            posRightTop.X = largeur -60;

            posLeftTop.X = 80;

        }

        public Coordinates PosLeftTop { get => posLeftTop; private set => posLeftTop = value; }
        public Coordinates PosRightTop { get => posRightTop; private set => posRightTop = value; }
        public Coordinates PosLeftBottom { get => posLeftBottom; private set => posLeftBottom = value; }
        public Coordinates PosRightBottom { get => posRightBottom; private set => posRightBottom = value; }
        public double PercentageWindow { get => percentageWindow; set => percentageWindow = value; }
    }
}
