﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace projet_kinect.Modèle
{


    public class Player : Entity
    {

        public static int CD1 = 2000;
        public static int CD2 = 5000;
        public static int CD3 = 10000;

        private List<Spell> spells;

        public Point MainDroite { get => mainDroite; set
            {
                mainDroite = value;
                mainDroite.X *= Constants.COEF_TAILLE;
                mainDroite.Y *= Constants.COEF_TAILLE;
            }
        }
        private Point mainDroite;

        public Point MainGauche { get => mainGauche; set
            {
                mainGauche = value;
                mainGauche.X *= Constants.COEF_TAILLE;
                mainGauche.Y *= Constants.COEF_TAILLE;
            }
        }
        public List<Spell> Spells { get => spells; set => spells = value; }

        private Point mainGauche;

        public Player(List<Spell> s, string name) : base()
        {
            Name = name;
            Spells = s;
        }

        public void UseSpellPosition(Spell s,double X =0, double Y =0)
        {
            s.Xpos = X;
            s.Ypos = Y;
        }

        public async Task<bool> UseSpellAsync (Spell s)
        {

            if (Spells.Contains(s) == false || Spells[Spells.IndexOf(s)].IsOnCooldown() == true )
            {
                return false;
            }
            UseSpellPosition(s, mainDroite.X, mainDroite.Y); /// A modifier en obtenant les valeurs du lancer
            Spells[Spells.IndexOf(s)].SetOnCooldown(true);
            await WaitCooldown(s);
            return true;
        }

        private async Task WaitCooldown (Spell s)
        {
            switch (Spells.IndexOf(s))
            {
                case 0:
                    await Waitcd1();
                    Spells[Spells.IndexOf(s)].SetOnCooldown(false);
                    
                    break;
                case 1:
                    await Waitcd2();
                    Spells[Spells.IndexOf(s)].SetOnCooldown(false);
                    break;
                case 2:
                    await Waitcd3();
                    Spells[Spells.IndexOf(s)].SetOnCooldown(false);
                    break;
                default:
                    break;


            }
        }


        

        async Task Waitcd1()
        {
            await Task.Delay(CD1);
          
        }

        async Task Waitcd2()
        {
            await Task.Delay(CD2);
        }
        async Task Waitcd3()
        {
            await Task.Delay(CD3);
        }
        public override string ToString()
        {
            return " Je suis " + Name + " et j'ai " + Hp + " points de vie";
        }

        public string ToStringCooldown()
        {
            return "Sort 1 : " + Spells[0].IsOnCooldown() +"\n" + "Sort 2 : " + Spells[1].IsOnCooldown() +"\n" + "Sort 3 : " + Spells[2].IsOnCooldown() + "\n";
        }


        

    }




}


