﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle
{
    /*
     * Class Entity, parent class for Monster and Player
     */
    public abstract class Entity
    {
        private string name;
        private int hp;
        private float xpos;
        private float ypos;
        private float zpos;

        private string desc;

        protected Entity()
        {
            Name = "Entity";
            desc = "Entity as an Entity";
            xpos = 0;
            ypos = 0;
            zpos = 0;
            Hp = 100;
        }

        protected Entity(int HP) : this()
        {
            hp = HP;
        }

        public void TakeDamage(int damage)
        {
            Hp -= damage;
        }

        public bool IsDead => hp <= 0;


        public int Hp
        {
            get => hp;
            set
            {
                hp = value;
            }
        }
        public float Xpos { get => xpos; set => xpos = value; }
        public float Ypos { get => ypos; set => ypos = value; }
        public float Zpos { get => zpos; set => zpos = value; }
        public string Name { get => name; set => name = value; }
       

        public override bool Equals(object obj)
        {
            return obj is Entity entity &&
                   name == entity.name &&
                   hp == entity.hp &&
                   xpos == entity.xpos &&
                   ypos == entity.ypos &&
                   zpos == entity.zpos &&
                   desc == entity.desc &&
                   Hp == entity.Hp &&
                   Xpos == entity.Xpos &&
                   Ypos == entity.Ypos &&
                   Zpos == entity.Zpos &&
                   Name == entity.Name;
        }

        public override int GetHashCode()
        {
            int hashCode = 125085274;
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(name);
            hashCode = hashCode * -1521134295 + hp.GetHashCode();
            hashCode = hashCode * -1521134295 + xpos.GetHashCode();
            hashCode = hashCode * -1521134295 + ypos.GetHashCode();
            hashCode = hashCode * -1521134295 + zpos.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(desc);
            hashCode = hashCode * -1521134295 + Hp.GetHashCode();
            hashCode = hashCode * -1521134295 + Xpos.GetHashCode();
            hashCode = hashCode * -1521134295 + Ypos.GetHashCode();
            hashCode = hashCode * -1521134295 + Zpos.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            return hashCode;
        }

        public override string ToString()
        {
            return base.ToString();
        }

    }
}
