﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle
{
    public class Spell
    {

        int damage;
        int cooldown;
        int range;
        double radius;
        private double xpos;
        private double ypos;
        private double zpos;
        private bool isOncooldown = false;


        public Spell(int dam, int cool, int rang, int rad)
        {
            damage = dam;
            cooldown = cool;
            range = rang;
            radius = rad;
            xpos = 0;
            ypos = 0;
            zpos = 0;
        }

        public double Xpos { get => xpos; set => xpos = value; }
        public double Ypos { get => ypos; set => ypos = value; }
        public double Zpos { get => zpos; set => zpos = value; }
        public int GetDamage()
        {
            return damage;
        }

        public int GetCooldown()
        {
            return cooldown;
        }

        public int GetRange()
        {
            return range;
        }

        public double GetRadius()
        {
            return radius;
        }

        public bool IsOnCooldown()
        {
            return isOncooldown;
        }

        public void SetOnCooldown(bool bol)
        {
            isOncooldown = bol;
        }
    }
}
