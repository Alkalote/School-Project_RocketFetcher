﻿using DotLiquid.Tags;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using projet_kinect.Modèle;

namespace projet_kinect.Modèle
{
    public class Monster : Entity
    {
        protected int damage;
        protected int moveSpeed;
        protected int powerLevel;
        protected string image;

        public Monster() : base()
        {
            Name = "Monster";
            damage = 3;
            moveSpeed = 25;
            powerLevel = 1;
            image = Constants.IMAGE_MONSTRE;
        }

        public int Damage { get => damage; set => damage = value; }
        public int MoveSpeed { get => moveSpeed; set => moveSpeed = value; }
        public int PowerLevel { get => powerLevel; set => powerLevel = value; }
        public string Image { get => image; set => image = value; }

        public override bool Equals(object obj)
        {
            return obj is Monster monster &&
                   base.Equals(obj) &&
                   Hp == monster.Hp &&
                   Xpos == monster.Xpos &&
                   Ypos == monster.Ypos &&
                   Zpos == monster.Zpos &&
                   Name == monster.Name &&
                   damage == monster.damage &&
                   Damage == monster.Damage;
        }

        public override int GetHashCode()
        {
            int hashCode = -1730187999;
            hashCode = hashCode * -1521134295 + Hp.GetHashCode();
            hashCode = hashCode * -1521134295 + Xpos.GetHashCode();
            hashCode = hashCode * -1521134295 + Ypos.GetHashCode();
            hashCode = hashCode * -1521134295 + Zpos.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Name);
            hashCode = hashCode * -1521134295 + damage.GetHashCode();
            hashCode = hashCode * -1521134295 + Damage.GetHashCode();
            return hashCode;
        }


        public void dealDamagePlayer(Player p)
        {
            p.TakeDamage(damage);
        }

        public string To_String()
        {
            return "Monstre " + this.Name + " ayant " + this.Hp + " points de vie, " + this.damage + " d'attaque et " + this.moveSpeed + " de vitesse de déplacement"+"\n"+"Je me situe en x:"+this.Xpos+" et en y:"+this.Ypos;
        }

    }
}
