﻿using projet_kinect.Modèle.Randomizer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projet_kinect.Modèle
{
    public class Manager
    {
        private List<Monster> list;
        private List<Monster> wave;
        private Player currPlayer;

        private int nbwaves = 1;
        private int maxMons = 4;
        private int minMons = 2;

        public List<Monster> List { get => list; set => list = value; }
        public Player CurrPlayer { get => currPlayer; set => currPlayer = value; }
        

        public Manager()
        {
            List = new List<Monster>();
            wave = new List<Monster>();
        }

        public void CheckSpellRadiusTargetsAndDamageMonsters(Spell s)
        {
            if (s.IsOnCooldown())
            {
                List<Monster> damaged = new List<Monster>();

                if (List.Count == 0) return;

                foreach (Monster m in List)
                {
                    /*  System.Console.WriteLine(s.GetRadius());

                     System.Console.WriteLine(s.Xpos - m.Xpos);

                     System.Console.WriteLine(s.Ypos - m.Ypos);

                     if ((s.Xpos - m.Xpos) <= s.GetRadius())
                     {
                         System.Console.WriteLine("OUI CEST VRAI");
                     }
                     else System.Console.WriteLine("NOOOOOOOOON");

                    if ( (s.Ypos - m.Ypos) <= s.GetRadius())
                     {
                         System.Console.WriteLine("OUI CEST VRAI");
                     }
                     else System.Console.WriteLine("NOOOOOOOOON");
                  */
                    if (Math.Abs(s.Xpos - m.Xpos) <= s.GetRadius() && Math.Abs(s.Ypos - m.Ypos) <= s.GetRadius())
                    {



                        damaged.Add(m);
                    }
                }
                DamageMonsters(damaged, s);
            }
        }


        public void DamageMonsters(List<Monster> mons, Spell s)
        {
            if (mons == null)
            {
                return;
            }

            foreach( Monster m in mons)
            {
                m.TakeDamage(s.GetDamage());
            }
        }

        public void CreateWave()
        {

            if (nbwaves % 10 != 1)
            {
                int rand = new RandomNumber().Next(maxMons, minMons);

                for (int i = 0; i <= rand; i++)
                {
                    wave.Add(new Monster());
                }
                nbwaves++;
            }

            else
            {
                maxMons += 2;
                minMons++;

                int rand = new RandomNumber().Next(maxMons, minMons);

                for (int i = 0; i <= rand; i++)
                {
                    Monster m = new Monster();
                    wave.Add(m);
                }
                nbwaves++;
            }
        }

        public void RandomizeWaveCoordinates(int height, int width)
        {
            foreach(Monster m in wave)
            {
                m.Ypos = new RandomNumber().Next(height);
                m.Xpos = new RandomNumber().Next(width,80);
            }
        }

        public void SummonWave(int height, int width)
        {
            CreateWave();
            RandomizeWaveCoordinates(height, width);

            foreach(Monster m in wave)
            {
                AddListMonster(m);
            }
            wave.Clear();

        }




        public void AddListMonster(Monster m)
        {
            List.Add(m);
        }


        public void MonsterListPosition()
        {
            foreach (Monster mon in list)
            {
                System.Console.WriteLine("PosX de " + mon.Name + " = "+mon.Xpos);
            }
        }

        public void WaveTo_String()
        {
            foreach(Monster m in wave)
            {
                Console.WriteLine(m.To_String());
            }
        }

        public override bool Equals(object obj)
        {
            return obj is Manager manager &&
                   EqualityComparer<List<Monster>>.Default.Equals(wave, manager.wave);
        }

        public override int GetHashCode()
        {
            return 2093036788 + EqualityComparer<List<Monster>>.Default.GetHashCode(wave);
        }
    }
}
