﻿using projet_kinect.Modèle;
using projet_kinect.Modèle.Controllers;
using projet_kinect.Modèle.GestureDetection;
using projet_kinect.Modèle.Randomizer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace projet_kinect.View
{
    public class EcranJeu : Ecrans
    {
        private Manager man = new Manager();
        private MoveController moveController;
        
        private readonly static double depMax = 0.7;

        private float score=0;
        int pos; // Hauteur max de spawn

        private Spell sortCourant;

        private int numSortCourant;

        private bool sortChanged = false;

        public EcranJeu(int largeur, int hauteur,Player p) : base(largeur, hauteur)
        {
            

            SpawnArea spawnZone = new SpawnArea(50, largeur, hauteur);
            pos = Convert.ToInt32(Math.Round(spawnZone.PercentageWindow * hauteur));
            Monster m1 = new Monster();
            m1.Xpos = Rand(largeur,80);
            m1.Ypos = Rand(pos);
            Monster m2 = new Monster();
            m2.Xpos = Rand(largeur,80);
            m2.Ypos = Rand(pos);
            Monster m3 = new Monster();
            m3.Xpos = Rand(largeur,80);
            m3.Ypos = Rand(pos);
            List<Monster> lmons = new List<Monster>();
            lmons.Add(m1);
            lmons.Add(m2);
            lmons.Add(m3);

            List<Spell> lspell = new List<Spell>();
            Spell s = new Spell(500, 10000, 500, 185);
            Spell s2 = new Spell(110, 5000, 550, 130);
            Spell s3 = new Spell(150, 2000, 450, 95);
            lspell.Add(s);
            lspell.Add(s2);
            lspell.Add(s3);

            p.Spells = lspell;
            sortCourant = p.Spells[0];
            numSortCourant = 0;
            moveController = new MoveController(p,lmons,depMax*hauteur);
            
            man.List = lmons;
            man.CurrPlayer = p;

            man.CreateWave();
            man.WaveTo_String();
            man.RandomizeWaveCoordinates(pos, largeur);
            man.WaveTo_String();

            GestureManager.GestureRecognised += DetectedGesture;
        }

        public int Rand(int taille, int min =0)
        {
            
           
                return new RandomNumber().Next(taille,min);
            
        }

        public override void SetFond(DrawingContext dc, int largeur, int hauteur)
        {
            //dc.DrawRectangle(Brushes.BlueViolet, null, Constants.AIR_DE_JEU(largeur, hauteur));
            dc.DrawImage(new BitmapImage(new Uri(Constants.IMAGE_FOND_JEU, UriKind.Relative)), Constants.AIR_DE_JEU(largeur, hauteur));
            if (sortCourant.IsOnCooldown())
                dc.DrawRectangle(Brushes.Red, null, Constants.SPELL_USED);
            else
                dc.DrawRectangle(Brushes.Yellow, null, Constants.SPELL_USED);
            String spellText;
            switch (numSortCourant)
            {
                case 0:
                    spellText = "S1";
                    break;
                case 1:
                    spellText = "S2";
                    break;
                case 2:
                    spellText = "S3";
                    break;
                default:
                    spellText = "Er";
                    break;
            }
            dc.DrawText(new FormattedText(spellText, CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 32 * Constants.COEF_TAILLE, Brushes.White), Constants.ORIGINE_SPELL_TEXT(Constants.SPELL_USED));
        }

        public void ShowMonsters(DrawingContext dc)
        {
            List<Monster> dead = new List<Monster>();
            foreach(Monster m in man.List)
            {
                if (m.IsDead)
                    dead.Add(m);
                else
                    dc.DrawImage(new BitmapImage(new Uri(m.Image, UriKind.Relative)), new Rect(m.Xpos, m.Ypos, 60, 80));
            }
            foreach (Monster m in dead)
            {
                man.List.Remove(m);
            }
        }



        public override Ecrans MajFenetre(Player p, DrawingContext drawingContext)
        {
            //p.TakeDamage(1);
            ShowMonsters(drawingContext);
            drawingContext.DrawText(new FormattedText(p.Hp.ToString(), CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 32 * Constants.COEF_TAILLE, Brushes.Red), new Point(0.0, 0.0));
            drawingContext.DrawText(new FormattedText(score.ToString(), CultureInfo.GetCultureInfo("fr-fr"), FlowDirection.LeftToRight, new Typeface("Verdana"), 32 * Constants.COEF_TAILLE, Brushes.White), new Point(0.0, 32*Constants.COEF_TAILLE));
            
            if (p.IsDead)
            {
                GestureManager.GestureRecognised -= DetectedGesture;
                return new EcranGameOver(largeur, hauteur);
            }
            else
                return this;
        }

        private void DetectedGesture(object sender, EventGesture e)
        {
            if (e.gesture.Equals(Constants.NOM_THROW_GESTURE))
                LancerBombe();
            else if (e.gesture.Equals(Constants.NOM_RIGHT_GESTURE))
                ChangerSort(numSortCourant+1);
            else if (e.gesture.Equals(Constants.NOM_LEFT_GESTURE))
                ChangerSort(numSortCourant-1);
            else if (e.gesture.Equals(Constants.NOM_REINITIALIZE_GESTURE))
                sortChanged = false;
        }

        private void LancerBombe()
        {
            man.CurrPlayer.UseSpellAsync(sortCourant);
            man.CheckSpellRadiusTargetsAndDamageMonsters(sortCourant);
        }

        private void ChangerSort(int newSpell)
        {
            if (!sortChanged)
            {
                if (newSpell < 0)
                    newSpell = 2;
                else if (newSpell > 2)
                    newSpell = 0;
                numSortCourant = newSpell;
                sortCourant = man.CurrPlayer.Spells[numSortCourant];
                sortChanged = true;
            }
        }
    }
}
