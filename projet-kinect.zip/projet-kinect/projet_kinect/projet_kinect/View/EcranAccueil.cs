﻿using projet_kinect.Modèle;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace projet_kinect.View
{
    public class EcranAccueil : Ecrans
    {
        private readonly Rect butonStart;

        private readonly FormattedText startText;

        private readonly Point origineTexte;

        public EcranAccueil(int largeur, int hauteur) : base(largeur, hauteur)
        {
            butonStart = Constants.BOUTON_START;
            startText = Constants.START_TEXT;
            origineTexte = Constants.ORIGINE_START_TEXT(butonStart);
        }

        public override void SetFond(DrawingContext dc, int largeur, int hauteur)
        {
            dc.DrawRectangle(Brushes.BurlyWood, null, Constants.AIR_DE_JEU(largeur, hauteur));
            dc.DrawRectangle(Brushes.Yellow, null, butonStart);
            dc.DrawText(startText, origineTexte);
        }

        public override Ecrans MajFenetre(Player p, DrawingContext drawingContext)
        {
            if (Collisions.ClickButton(p.MainDroite, p.MainGauche, butonStart))
                return new EcranJeu(largeur, hauteur,p);
            else
                return this;
        }
    }
}
