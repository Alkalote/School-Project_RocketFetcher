﻿using projet_kinect.Modèle;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace projet_kinect.View
{
    public abstract class Ecrans
    {
        public DrawingGroup DrawingGroup { get=>drawingGroup;  }
        private readonly DrawingGroup drawingGroup=new DrawingGroup();

        private readonly Brush handefaultBrush = Constants.COULEUR_MAIN;

        private readonly int handSize = Constants.TAILLE_MAIN;

        protected readonly int largeur;

        protected readonly int hauteur;

        public ImageSource ImageSource { get => imageSource; }
        protected readonly DrawingImage imageSource;

        public bool HaveChanged
        {
            get
            {
                if (haveChanged)
                {
                    haveChanged = false;
                    return true;
                }
                return false;
            }
        }
        private bool haveChanged=true;

        public Ecrans(int largeur, int hauteur)
        {
            imageSource = new DrawingImage(drawingGroup);
            this.largeur = largeur;
            this.hauteur = hauteur;
        }

        public abstract void SetFond(DrawingContext dc, int largeur, int hauteur);

        public abstract Ecrans MajFenetre(Player p, DrawingContext drawingContext);

        public void DessinerMains(Player p, DrawingContext drawingContext)
        {
            drawingContext.DrawEllipse(handefaultBrush, null, p.MainDroite, handSize, handSize);
            drawingContext.DrawEllipse(handefaultBrush, null, p.MainGauche, handSize, handSize);
        }
    }
}
