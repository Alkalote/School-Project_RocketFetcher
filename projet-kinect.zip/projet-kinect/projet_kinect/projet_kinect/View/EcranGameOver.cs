﻿using projet_kinect.Modèle;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace projet_kinect.View
{
    public class EcranGameOver : Ecrans
    {
        private readonly Rect butonStop;

        private readonly FormattedText endButtonText;

        private readonly FormattedText endText;

        private readonly Point originButtonText;

        private readonly Point originEndText;

        public EcranGameOver(int largeur, int hauteur) : base(largeur, hauteur)
        {
            butonStop = Constants.BOUTON_STOP;
            endButtonText = Constants.END_TEXT_BUTTON;
            originButtonText = Constants.ORIGINE_END_TEXT_BUTTON(butonStop);
            endText = Constants.END_TEXT;
            originEndText = Constants.ORIGINE_END_TEXT;
        }

        public override void SetFond(DrawingContext dc, int largeur, int hauteur)
        {
            dc.DrawRectangle(Brushes.Black, null, Constants.AIR_DE_JEU(largeur, hauteur));
            dc.DrawRectangle(Brushes.Green, null, butonStop);
            dc.DrawText(endButtonText, originButtonText);
            dc.DrawText(endText, originEndText);
        }

        public override Ecrans MajFenetre(Player p, DrawingContext drawingContext)
        {
            if (Collisions.ClickButton(p.MainDroite, p.MainGauche, butonStop))
                return new EcranAccueil(largeur, hauteur);
            else
                return this;
        }
    }
}
