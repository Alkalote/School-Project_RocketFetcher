﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;
using projet_kinect.Modèle;
using projet_kinect.Modèle.Controllers;
using projet_kinect.Modèle.GestureDetection;
using projet_kinect.View;
using static projet_kinect.Modèle.Constants;

namespace projet_kinect
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        private KinectSensor sensor;

        private BodyFrameReader bodyFrameReader = null;

        private Body[] bodies = null;

        private readonly int hauteur;

        private readonly int largeur;

        private Ecrans ecran;

        private readonly Player p=new Player(new List<Spell>(), "hero");

        public event PropertyChangedEventHandler PropertyChanged;

        public String StatutKinect
        {
            get => statutKinect;
            set
            {
                statutKinect = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("StatutKinect"));
            }
        }
        private String statutKinect;

        public int NbLancer
        {
            get => nbLancer;
            set
            {
                nbLancer = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("NbLancer"));
            }
        }
        private int nbLancer=0;

        public ImageSource ImageSource { get => ecran.ImageSource;  }

        public MainWindow()
        {
            DataContext = this;

            sensor = KinectSensor.GetDefault();
            sensor.Open();
            sensor.IsAvailableChanged += ChangementDetectionKinect;
            StatutKinect = sensor.IsAvailable ? KINECT_BRANCHEE : KINECT_NON_BRANCHEE;

            largeur = sensor.DepthFrameSource.FrameDescription.Width*Constants.COEF_TAILLE;
            hauteur = sensor.DepthFrameSource.FrameDescription.Height*Constants.COEF_TAILLE;

            ecran = new EcranAccueil(largeur, hauteur);

            bodyFrameReader = sensor.BodyFrameSource.OpenReader();
            if (bodyFrameReader != null)
            {
                bodyFrameReader.FrameArrived += Reader_FrameArrived;
            }

            GestureManager.AddGestureRecognised(new ThrowGesture());
            GestureManager.GestureRecognised += DetectionGestureTest;
            GestureManager.AddGestureRecognised(new GestLeft());
            GestureManager.AddGestureRecognised(new GestRight());
            GestureManager.AddGestureRecognised(new ReinitializeGest());

            InitializeComponent();
        }
        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            if (bodyFrameReader != null)
            {
                bodyFrameReader.Dispose();
                bodyFrameReader = null;
            }

            if (sensor != null)
            {
                sensor.Close();
                sensor = null;
            }
        }

        private void ChangementDetectionKinect(object sender, IsAvailableChangedEventArgs e)
        {
            StatutKinect = sensor.IsAvailable ? KINECT_BRANCHEE : KINECT_NON_BRANCHEE;
        }

        private void DetectionGestureTest(object sender, EventGesture e)
        {
            if (e.gesture.Equals(NOM_STUB_GESTURE))
            {
                Console.WriteLine("stub");
            }
            else if (e.gesture.Equals(NOM_THROW_GESTURE))
            {
                Console.WriteLine("throw "+nbLancer);
                NbLancer++;
            }
        }

        private void Reader_FrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            bool dataReceived = false;

            using (BodyFrame bodyFrame = e.FrameReference.AcquireFrame())
            {
                if (bodyFrame != null)
                {
                    if (bodies == null)
                    {
                        bodies = new Body[bodyFrame.BodyCount];
                    }

                    bodyFrame.GetAndRefreshBodyData(bodies);
                    dataReceived = true;
                }
            }

            if (dataReceived)
            {
                using (DrawingContext dc = ecran.DrawingGroup.Open())
                {
                    // prevent drawing outside of our render area
                    ecran.DrawingGroup.ClipGeometry = new RectangleGeometry(AIR_DE_JEU(largeur, hauteur));

                    ecran.SetFond(dc, largeur, hauteur);

                    //dessine les corps détecté un par un
                    foreach (Body body in bodies)
                    {
                        if (body.IsTracked)
                        {
                            IReadOnlyDictionary<JointType, Joint> joints = body.Joints;

                            // convert the joint points to depth (display) space
                            Dictionary<JointType, Point> jointPoints = new Dictionary<JointType, Point>();

                            foreach (JointType jointType in joints.Keys)
                            {
                                // sometimes the depth(Z) of an inferred joint may show as negative
                                // clamp down to 0.1f to prevent coordinatemapper from returning (-Infinity, -Infinity)
                                CameraSpacePoint position = joints[jointType].Position;
                                if (position.Z < 0)
                                {
                                    position.Z = 0.1f;
                                }

                                DepthSpacePoint depthSpacePoint = sensor.CoordinateMapper.MapCameraPointToDepthSpace(position);
                                jointPoints[jointType] = new Point(depthSpacePoint.X, depthSpacePoint.Y);
                            }

                            p.MainDroite = jointPoints[JointType.HandRight];
                            p.MainGauche = jointPoints[JointType.HandLeft];
                            ecran.DessinerMains(p, dc);
                            ecran = ecran.MajFenetre(p, dc);
                            if (ecran.HaveChanged)
                            {
                                p.Hp = 100;
                                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("ImageSource"));
                            }

                            GestureManager.OnFrameReceived(joints);
                        }
                    }
                }
            }
        }






        private async Task TestClasses()
        {
            Monster m = new Monster();
            Monster m2 = new Monster();
            Monster m3 = new Monster();

            m3.Hp = 150;
            m2.Hp = 150;
            m.Hp = 150;


            m3.MoveSpeed = 12;
            m2.MoveSpeed = 7;
            

            Spell s = new Spell(500, 10000, 500, 185);
            Spell s2 = new Spell(110, 5000, 550, 120);
            Spell s3 = new Spell(150, 2000, 450, 95);
            List<Spell> n = new List<Spell>();
            n.Add(s);
            n.Add(s2);
            n.Add(s3);
            Player p = new Player(n, "Le Joueur");

            Manager man = new Manager();
            man.AddListMonster(m);
            man.AddListMonster(m2);
            man.AddListMonster(m3);

            TimerW t = new TimerW();

            System.Console.WriteLine(p.ToString());
            System.Console.WriteLine(p.ToStringCooldown());
            System.Console.WriteLine(t.GetTimeWaited().ToString());
            p.UseSpellAsync(n[0]);

            p.UseSpellAsync(n[1]);



            System.Console.WriteLine(p.ToStringCooldown());
            await Task.Delay(3000);
            p.UseSpellAsync(n[2]);
            p.UseSpellAsync(n[2]);
            await Task.Delay(11000);
            System.Console.WriteLine(p.ToStringCooldown());

            System.Console.WriteLine(t.GetTimeWaited().ToString());

            System.Console.WriteLine(" ");
            System.Console.WriteLine("---------------------------------------------------");
            System.Console.WriteLine(" ");
            System.Console.WriteLine(p.Hp);
            foreach (Monster monster in man.List)
            {
                monster.dealDamagePlayer(p);
                System.Console.WriteLine(p.Hp);
            }
            System.Console.WriteLine(" ");
            System.Console.WriteLine(p.ToStringCooldown());


            System.Console.WriteLine(" ");
            System.Console.WriteLine("---------------------------------------------------");
            System.Console.WriteLine(" ");
            System.Console.WriteLine(" Test d'un sort ");
            System.Console.WriteLine(" ");

            foreach (Monster mons in man.List)
            {
                System.Console.WriteLine(mons.Hp);
            }

            man.List[2].Xpos = 10;
            man.List[1].Xpos = 3;

            

            //man.MonsterListPosition();
            MoveController controller = new MoveController(p, man.List,1500);

            int prevtime= t.GetTimeWaited();
            System.Console.WriteLine("On en est la :" + DateTime.Now);
            while (t.GetTimeWaited() < 25)
            {
                await (Task.Delay(200));

                if (t.GetTimeWaited() - prevtime ==1)
                {
                    prevtime = t.GetTimeWaited();

                    System.Console.WriteLine("                   ");
                    System.Console.WriteLine("                   ");
                    man.MonsterListPosition();
                }

            }



            man.CheckSpellRadiusTargetsAndDamageMonsters(p.Spells[1]);

            foreach (Monster mons in man.List)
            {
                System.Console.WriteLine(mons.Hp);
            }

            man.CheckSpellRadiusTargetsAndDamageMonsters(p.Spells[0]);

            foreach (Monster mons in man.List)
            {
                System.Console.WriteLine(mons.Hp);
            }


            System.Console.WriteLine("Voila le moment de fin du prog :"+DateTime.Now);
            System.Console.WriteLine(t.GetTimeWaited());
        }

  

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //await TestClasses();
        }
    }
}
