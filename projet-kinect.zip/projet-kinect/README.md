# Projet Kinect

Projet de jeu effectué via Kinect sur VisualStudio.

-------- Comment (Pouvoir) Jouer ?

1-Télécharger le .zip ou Cloner le dépot et lancer l'Application sur Visual Studio

2-Brancher une Kinect fonctionnelle sur votre appareil

3-Lancer l'Application et naviguer via la Kinect avec vos mains pour appuyer sur "Play"

-------- Quel est l'objectif ?

Il faut survivre à des hordes d'ennemis grâce aux compétences de nos personnages (choisissable après avoir appuyé sur "Play") tout en faisant attention au temps de récupération de ces dernières pour ne pas se retrouver acculé.
On aura un score en fonction du temps de survie ainsi que du nombre de monstres tués ainsi que leur niveau de puissance.
Pour lancer les compétences associées au personnage choisi, il faut faire des gestes:
	
	-(Avec le bras droit) Un geste de lancer avec une position de main droite de départ au même niveau que l'épaule droite et une position finale pas trop basse pour que le mouvement soit détecté.
	-(Avec le bras gauche) Un geste vers la gauche permet d'aller sur la compétence précédente alors qu'un un geste vers la droite nous donne accès à la suivante.

